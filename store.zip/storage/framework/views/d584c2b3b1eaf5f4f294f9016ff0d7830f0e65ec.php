
<?php $__env->startPush('class'); ?>
    class="addproduct"
<?php $__env->stopPush(); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="/css/addproduct.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="/js/addproduct.js"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('block'); ?>

<main class="d-flex justify-content-center">
<div>
    <h4>Adding a product</h4>
    <form action="/product" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="text" placeholder="Product name" name="name" class="mb-5">


        <div class="fileinput">

            <label class="src" data-text="Upload file">Mainphoto</label>
            <div>
                <label title="Upload" data-toggle="tooltip"><input type='file' name="image" id="file"
                        required>Browse</label>
            </div>
        </div><br>

        <label class="fileuploadstatus text-success"></label>

        <div class="progress dnone">
            <div class="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0"
                aria-valuemax="100">0%</div>
        </div>

        <h6>Description</h6><br>
        <textarea name="description" placeholder="Type..."></textarea>
        <br>
        <input name="price" type="text" class="mt-4" placeholder="Price"
            style="min-width: 120px; width: 120px; text-align: center;">
        <label class="text-secondary ml-4"> Max price - $200 000</label><br>

        <select name="category">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>


        

<button>Add</button>
</form>






</div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My files\My projects\laravel\estore\resources\views/create.blade.php ENDPATH**/ ?>