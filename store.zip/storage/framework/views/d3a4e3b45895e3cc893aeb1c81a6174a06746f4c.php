
<?php $__env->startPush('class'); ?>
class="cart"
<?php $__env->stopPush(); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="/css/cart.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="/js/addproduct.js"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('block'); ?>


<main class="d-flex justify-content-center pb-5">

    <div>
        <h4>My Cart</h4>
        <hr>
        <?php if(empty($cards)): ?>
            <p>No products</p>
        <?php else: ?>
            
        <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="product d-flex">
            <img style=" height: 400px;width: 400px;object-fit: contain;" src="uploads/images/<?php echo e($card->product->image); ?>" alt="">
            <div class="details pl-5">
                <h5 class="mb-4"><?php echo e($card->product->name); ?></h5>
                <p><?php echo e($card->product->description); ?></p>
                <div class="product_footer d-flex align-items-center mt-5">
                    <label class="mr-auto"> Price: $<?php echo e($card->product->price); ?></label>
                    <a href="/buy/<?php echo e($card->product->id); ?>">Buy</a>
                    <a href="/delete/<?php echo e($card->id); ?>" class="remove" data-id="14"><i
                                class="fas fa-trash"></i></a>
                </div>
            </div>
        </div>

        <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        
        <a href="/buyall">Buy All</a>


    </div>



</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My files\My projects\laravel\estore\resources\views/card.blade.php ENDPATH**/ ?>