
<?php $__env->startPush('class'); ?>
class="payment"
<?php $__env->stopPush(); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="/css/payment.css">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('block'); ?>

<main class="d-flex justify-content-center">

    <div>
        <h4>Making a payment</h4>
        <div class="success">
            <img src="/images/tick.png">
            <h5>Congratulations! Your payment is proceeded</h5>
            <a href="/" class="sitebtn">Go to Home</a>
        </div>






    </div>



</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My files\My projects\laravel\estore\resources\views/checkout.blade.php ENDPATH**/ ?>