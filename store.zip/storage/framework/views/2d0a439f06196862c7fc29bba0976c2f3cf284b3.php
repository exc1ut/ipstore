<?php $__env->startPush('class'); ?>
class="admin"
<?php $__env->stopPush(); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="css/admin.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="/js/addproduct.js"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('block'); ?>


<main class="d-flex justify-content-center">
    <div>
        <h4>Administrating panel</h4>
            <?php if(empty($products)): ?>
            <p>No products</p>
            <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Product Name</th>
                        <th scope="col">Price</th>
                        <th scope="col">Delete</th>
                    </tr>
                </thead>
                <tbody>


                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($product->id); ?></th>
                        <td><?php echo e($product->name); ?></td>
                        <td>$<?php echo e($product->price); ?></td>
                        <td>
                            <form action="/product/<?php echo e($product->id); ?>" method="post">
                                <?php echo method_field("DELETE"); ?>
                                <?php echo csrf_field(); ?>
                                <input type="submit" value="delete">
                            </form>
                        </td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                </tbody>
            </table>
            <?php endif; ?>






    </div>



</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My files\My projects\laravel\estore\resources\views/home.blade.php ENDPATH**/ ?>