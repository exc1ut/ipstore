
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="/css/view.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('block'); ?>
<main class="p-5 view">
<div class="d-flex">
    <img style=" height: 400px;width: 400px;object-fit: contain;" src="/uploads/images/<?php echo e($product->image); ?>">
    <div class="details pl-5">
    <h2 class="pb-4"><?php echo e($product->name); ?></h2>
        <p>
            <?php echo e($product->description); ?>

        </p>

        <div class="mt-5">
            <a href="/buy/<?php echo e($product->id); ?>" class="buy">Buy</a>
            <a href="/add/<?php echo e($product->id); ?>" class="add2cart">Add to Cart</a>
        </div>
        <div style="margin-top:25px;">
            <br>
            Seller:<a href="/seller/<?php echo e($product->user->id); ?>"><?php echo e($product->user->name); ?></a><br>
            <br>
            Category:<a href="/category/<?php echo e($product->category_id); ?>"><?php echo e($product->category->name); ?></a>
        </div>
    </div>

</div>
<a role="button" href="/" class="btn btn-primary text-white mt-5">Go Back</a>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My files\My projects\laravel\estore\resources\views/view.blade.php ENDPATH**/ ?>