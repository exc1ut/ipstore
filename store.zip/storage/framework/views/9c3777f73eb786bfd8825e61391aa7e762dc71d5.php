
<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="/css/style.css">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('block'); ?>
<main class="d-flex justify-content-center">
<aside>
    <h6>Categories</h6>
    <ul>

        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="/category/<?php echo e($category->id); ?>" class="active"><?php echo e($category->name); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>
</aside>
<div class="products flex-grow-1">
 
    <?php if(isset($categoryName)): ?>
<h2><?php echo e($categoryName); ?></h2>
    <?php else: ?>
        <h2>Products</h2>
    <?php endif; ?>


    <hr>
    <div class="d-flex mt-5 flex-wrap justify-content-between">

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <label class="new">New</label>
            <a href="/product/<?php echo e($product->id); ?>"><img src="/uploads/images/<?php echo e($product->image); ?>"></a>
                <div class="details p-4">
                    <h3 class="mb-3"><?php echo e($product->name); ?></h3>
                    <label class="mb-4">$<?php echo e($product->price); ?></label><br>
                    <a href="/add/<?php echo e($product->id); ?>" class="add2cart" data-id="12">Add to cart</a>
                </div>
            </div>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My files\My projects\laravel\estore\resources\views/index.blade.php ENDPATH**/ ?>